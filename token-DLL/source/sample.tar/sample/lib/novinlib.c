/*******************************************************
 Windows HID simplification

 Alan Ott
 Signal 11 Software

 8/22/2009

 Copyright 2009, All Rights Reserved.
 
 This contents of this file may be used by anyone
 for any reason without any conditions and may be
 used as a starting point for your own applications
 which use HIDAPI.
********************************************************/

#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include "hidapi.h"
#include "novinlib.h"


int write_usb (const unsigned char *serialNo, const unsigned char *pwd, const char *data, const int datalen)
{
	#define REPORTID_SETBLOCK 0x04
	#define WRITE_CMD 0x41
	#define SERIALNO_INDEX 2
	#define PWD_INDEX 6
	#define DATA_INDEX 24
	#define DATALEN_INDEX 34

	int res;
	unsigned char buff[41];
	hid_device *handle;

	handle = hid_open(VID, PID, NULL);
	if (!handle) {
		printf("unable to open device\n");
 		return 1;
	}

	memset(buff, 0, sizeof(buff));

	buff[0] = REPORTID_SETBLOCK;

	buff[1] = WRITE_CMD;
	
	memcpy (buff+SERIALNO_INDEX, serialNo, 4); //copy serial number.

	memcpy (buff+PWD_INDEX, pwd, 16); //copy password.

	buff[22] = 0;
	buff[23] = 0;

	if ( datalen>=0 && datalen<=10){
		memcpy (buff+DATA_INDEX, data, datalen);
		buff[DATALEN_INDEX] = datalen;
	} else {
		memcpy (buff+DATA_INDEX, data, 10);
		buff[DATALEN_INDEX] = 10;
	}


	res = hid_send_feature_report(handle, buff, sizeof(buff));
	if (res < 0) {
		printf("Unable to send a feature report.\n");
	}

	memset (buff, 0, sizeof(buff));

	// Read a Feature Report from the device
	buff[0] = 0x1;
	res = hid_get_feature_report (handle, buff, sizeof(buff));
	if (res < 0) {
		printf("Unable to get a feature report.\n");
		printf("%ls", hid_error(handle));
	}

	
        #undef REPORTID_SETBLOCK
	#undef WRITE_CMD
	#undef SERIALNO_INDEX
	#undef PWD_INDEX
	#undef DATA_INDEX
	#undef DATALEN_INDEX

	hid_close (handle);

	return buff[1];
}

int read_usb (const unsigned char *serialNo, const unsigned char *pwd, char *data, const int datalen)
{
	#define REPORTID_SETBLOCK 0x03
	#define READ_CMD 0x40
	#define SERIALNO_INDEX 2
	#define PWD_INDEX 6
	#define DATALEN_INDEX 24

	int res;
	unsigned char buff[41];
	hid_device *handle;


	handle = hid_open(VID, PID, NULL);
	if (!handle) {
		printf("unable to open device\n");
 		return 1;
	}

	memset(buff, 0, sizeof(buff));

	buff[0] = REPORTID_SETBLOCK;
	buff[1] = READ_CMD;

	memcpy (buff+SERIALNO_INDEX, serialNo, 4); //copy serial number.

	memcpy (buff+PWD_INDEX, pwd, 16); //copy password.

	buff[22] = 0;
	buff[23] = 0;

	if ( datalen>=0 && datalen<=10)
		buff [DATALEN_INDEX] = datalen;
	else
		buff [DATALEN_INDEX] = 10;

	res = hid_send_feature_report(handle, buff, sizeof(buff));
	if (res < 0) {
		printf("Unable to send a feature report.\n");
		}

	memset (buff, 0, sizeof(buff));

	// Read a Feature Report from the device
	buff[0] = 0x2;
	res = hid_get_feature_report (handle, buff, sizeof(buff));
	if (res < 0) {
		printf("Unable to get a feature report.\n");
		printf("%ls", hid_error(handle));
	}

       	memcpy (data, buff+2, datalen); //copy data.

	#undef REPORTID_SETBLOCK
	#undef READ_CMD
	#undef SERIALNO_INDEX
	#undef PWD_INDEX
	#undef DATALEN_INDEX

	hid_close (handle);
	return buff[1];
}
