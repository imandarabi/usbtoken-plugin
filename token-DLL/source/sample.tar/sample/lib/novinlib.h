
#define VID 0x03eb
#define PID 0x8ac9

int write_usb (const unsigned char *serialNo, const unsigned char *pwd, const char *data, const int datalen);
int read_usb (const unsigned char *serialNo, const unsigned char *pwd, char *data, const int datalen);
