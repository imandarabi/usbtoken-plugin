#include <stdio.h>
#include <wchar.h>
#include <string.h>
#include <stdlib.h>
#include "lib/novinlib.h"


int main(int argc, char* argv[])
{

	const unsigned char serial[4] = {109, 232, 151, 192};
	const unsigned char pwd[16] = {52, 53, 54, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
	const char data[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	char read_buff[18];


	printf ("write result is : %d \n\n", write_usb (serial, pwd, data, sizeof(data)) ); 
	memset(read_buff,0,sizeof(read_buff));

	printf ("read result is : %d \n\n", read_usb (serial, pwd, read_buff, sizeof(read_buff)) );
	
	int i;
	for (i=0; i<10; i++)
		printf("%d ",read_buff[i]);
	printf("\n\n");

	return 0;
}
