salam . 
faghat kafi hast ke gcc ro ye system et nastb dashte bashiiii. 
./make ( compiles ... )
./make clean ( clean compiled files )

note : hatman file e ./sample ro ba root ejra kon ... . 

source ee ke read va write tosh hast : ./lib/novinlib.c 
